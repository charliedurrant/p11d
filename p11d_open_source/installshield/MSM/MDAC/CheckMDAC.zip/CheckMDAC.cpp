#pragma comment(lib, "msi.lib")
#pragma comment(linker, "/defaultlib:version.lib")

// inclue standard windows and MSI Headers
#include < windows.h >
#include < msi.h >
#include < msiquery.h >
#include "stdstring.h"


UINT __stdcall CheckMDAC26SP1(MSIHANDLE hInstall)
{
	char buffer[256];
	DWORD dwVerInfoSize;
	LPSTR lpVersion;
	DWORD dwVerHnd=0;
	UINT uVersionLen;
	BOOL bRetCode;
	CStdString libvar;
	libvar = getenv( "ProgramFiles");
	CStdString source = libvar + "\\Common Files\\System\\ado\\msado15.dll";
	dwVerInfoSize = GetFileVersionInfoSize(source.GetBuffer(source.GetLength()), &dwVerHnd);
	if (dwVerInfoSize)
	{
		LPSTR lpstrVffInfo;
		HANDLE hMem;
		hMem = GlobalAlloc(GMEM_MOVEABLE, dwVerInfoSize);
		lpstrVffInfo = (char *)GlobalLock(hMem);
		GetFileVersionInfo(source.GetBuffer(source.GetLength()),dwVerHnd, dwVerInfoSize, lpstrVffInfo);

		bRetCode = VerQueryValue((LPVOID)lpstrVffInfo,TEXT("\\"),(LPVOID *)&lpVersion,&uVersionLen);
		if(bRetCode)
		{
			VS_FIXEDFILEINFO *pverFixed;
			pverFixed=(VS_FIXEDFILEINFO*)lpVersion;
			sprintf(buffer,"%hd.%hd.%hd.%hd",
				HIWORD(pverFixed->dwFileVersionMS),
				LOWORD(pverFixed->dwFileVersionMS),
				HIWORD(pverFixed->dwFileVersionLS),
				LOWORD(pverFixed->dwFileVersionLS));
			if (HIWORD(pverFixed->dwFileDateMS) > 2)
			{
				MsiSetProperty(hInstall, TEXT("INSTALL_MDAC"), NULL);
			} else {
				if (LOWORD(pverFixed->dwFileVersionMS) >= 61)
				{
					MsiSetProperty(hInstall, TEXT("INSTALL_MDAC"), NULL);
				} else {
					MsiSetProperty(hInstall, TEXT("INSTALL_MDAC"), TEXT("1"));
					MsiSetMode(hInstall, MSIRUNMODE_REBOOTNOW, TRUE);
				}
			}
		}
		else
		{
			MsiSetProperty(hInstall, TEXT("INSTALL_MDAC"), NULL);
		}
	}
	return ERROR_SUCCESS;
}

UINT __stdcall CheckMDAC7RTM(MSIHANDLE hInstall)
{
	char buffer[256];
	DWORD dwVerInfoSize;
	LPSTR lpVersion;
	DWORD dwVerHnd=0;
	UINT uVersionLen;
	BOOL bRetCode;
	CStdString libvar;
	libvar = getenv( "ProgramFiles");
	CStdString source = libvar + "\\Common Files\\System\\ado\\msado15.dll";
	dwVerInfoSize = GetFileVersionInfoSize(source.GetBuffer(source.GetLength()), &dwVerHnd);
	if (dwVerInfoSize)
	{
		LPSTR lpstrVffInfo;
		HANDLE hMem;
		hMem = GlobalAlloc(GMEM_MOVEABLE, dwVerInfoSize);
		lpstrVffInfo = (char *)GlobalLock(hMem);
		GetFileVersionInfo(source.GetBuffer(source.GetLength()),dwVerHnd, dwVerInfoSize, lpstrVffInfo);

		bRetCode = VerQueryValue((LPVOID)lpstrVffInfo,TEXT("\\"),(LPVOID *)&lpVersion,&uVersionLen);
		if(bRetCode)
		{
			VS_FIXEDFILEINFO *pverFixed;
			pverFixed=(VS_FIXEDFILEINFO*)lpVersion;
			sprintf(buffer,"%hd.%hd.%hd.%hd",
				HIWORD(pverFixed->dwFileVersionMS),
				LOWORD(pverFixed->dwFileVersionMS),
				HIWORD(pverFixed->dwFileVersionLS),
				LOWORD(pverFixed->dwFileVersionLS));
			if (HIWORD(pverFixed->dwFileDateMS) > 2)
			{
				MsiSetProperty(hInstall, TEXT("INSTALL_MDAC"), NULL);
			} else {
				if (LOWORD(pverFixed->dwFileVersionMS) >= 70)
				{
					MsiSetProperty(hInstall, TEXT("INSTALL_MDAC"), NULL);
				} else {
					MsiSetProperty(hInstall, TEXT("INSTALL_MDAC"), TEXT("1"));
					MsiSetMode(hInstall, MSIRUNMODE_REBOOTNOW, TRUE);
				}
			}
		}
		else
		{
			MsiSetProperty(hInstall, TEXT("INSTALL_MDAC"), NULL);
		}
	}
	return ERROR_SUCCESS;
}

ComponentOne True DBGrid Pro 6.0f                                 
Build 6.0.0253  ("Poet's Garden")         
December 12, 2000
----------------------------------------------------------------------


========
Contents
========

(1)  ComponentOne Web Site
(2)  What's New
(3)  Changes and Bug Fixes
(4)  Explanation of ICursor and OLE DB
(5)  *** IMPORTANT: OLE DB Bug Information ***
(6)  Samples and Tutorials
(7)  Migration
(8)  Distribution Requirements



================================================
(1) ComponentOne Web Site
================================================

All product updates for ComponentOne products can be downloaded from the ComponentOne
Web Site at:

  http://www.componentone.com/

or from our anonymous FTP server at:

  ftp://ftp.apexsc.com/


The ComponentOne Web site at www.componentone.com also provides a wealth 
of information and software downloads for True DBGrid Pro 6.0 users:

* Latest news and information about ComponentOne products
* Free product updates, which provide you with bug fixes and new
  features
* Free Sample programs which provide detailed illustrations of
  advanced concepts
* Answers to frequently asked questions (FAQ's) about ComponentOne products
* Trial versions and demos for ComponentOne products
* Lists of ComponentOne Resellers and ordering information 




================================================
(2) What's New
================================================

The following list describes new features in recent releases.


Version 6.0e ("Starry Night"), Build 6.0.0240
----------------------------------------------------

* Three new grid properties called DestinationCol, DestinationRow, and
  DestinationSplit were added.  These properties are accessible in all 
  events fired during cell transition initiated with mouse or keyboard.
  (See the documentation for a complete list.)  They can be used to 
  determine which grid cell will be the object of the movement.  An 
  attempt to retrieve any of these three properties outside these 
  events, or when cell transition is not caused by mouse or keyboard 
  action, results in an error: "Property is not available in this 
  context".

* A new Error object and Errors collection has been added to the OLE DB 
  grid only.  The collection is read-only and available only at run
  time. It is used to provide complete information about all cascading 
  errors generated as the result of a failed database operation.  Both 
  objects are modeled after their ADO counterparts, ADODB.Error and 
  ADODB.Errors.  For more information, see the documentation.

* A True DBCombo control may now be used as the ExternalEditor for a
  grid column.




Version 6.0d ("Four Cut Sunflowers"), Build 6.0.0235
----------------------------------------------------

* Tooltips are now displayed when resting the mouse cursor over the
  toolbar buttons in PrintPreview mode.

* A new DeadAreaBackColor property has been added to the grid. Setting 
  this property will affect the appearance of the "dead area" of 
  underpopulated grids.  NOTE: If the EmptyRows property is True,
  the "empty" rows are NOT considered part of the "dead area" and 
  will NOT be displayed in the DeadAreaBackColor.  To achieve this 
  effect, set the EmptyRows property to False, and set the 
  DeadAreaBackColor property to the desired color.

* A new MaxRows property has been added to the grid.  This property
  controls the maximum number of data rows that can be displayed in the
  grid at any one time.	The default value for this property is 250,000.
  Any rows in the grid's data source in excess of MaxRows will not be
  scrolled into view when using the grid's verical scroll bar.
  Therefore, if you wish to navigate within a data source that contains
  more than 250,000 rows, use this property to extend the limit. The
  minimum possible value of this property is 250,000 (the default), so
  if you display less than 250,000 rows in the grid, there is no need
  to set this property.

* A new boolean NoClipping property has been added to the PrintInfo
  object. The default is False. If set to True, any text inside the
  list cells will be drawn without clipping during print and print 
  preview operations. With some printer/font combinations, the size 
  required to print certain text is sometimes reported incorrectly,
  which can result in undesired clipping of letters when there should 
  be none. If this occurs, the PrintInfo.NoClipping property should be 
  set to True. This will prevent clipping. This property should be
  used with caution, as in certain cases where clipping *is* desired 
  it can result in cells' contents overflowing into other cells.

* A new OwnerDrawCellPrint event has been added to the grid. This 
  event is only fired for columns in which the OwnerDraw property is 
  set to True. You can use this event to customize the appearance of 
  individual cells by drawing directly to the printer device context 
  using standard Windows GDI calls. Note that this is an enhanced 
  metafile device context, so some operations (such as BitBlt) are not 
  available.

* A PageSetupCancelled property has been added to the PrintInfo
  object. It is a read-only boolean property available only at run
  time.  The value of the property is True if the most recent 
  PageSetup dialog was cancelled by pressing the Cancel command 
  button or the close button in the upper right corner, False if the 
  OK command button was pressed.  If the PageSetup dialog has not yet 
  been displayed, the value of the property is meaningless, and 
  should be considered undefined.

* A new PreviewMaximize property has been added to the PrintInfo 
  object.  If True, the preview window is initially maximized
  whenever it is displayed.  The default value is False.

* A new UnitsPerInch property has been added to the PrintInfo object.
  Use this property to determine the logical resolution of a printer
  device context.  You do not need to use this property unless your 
  application uses owner-drawn cells in conjunction with the PrintData 
  or PrintPreview methods. When creating fonts for use in the
  OwnerDrawCellPrint event, you can use the value returned by the 
  UnitsPerInch property to calculate the appropriate font size.




Version 6.0c ("Green Wheat Fields"), Build 6.0.0220
----------------------------------------------------

Enhanced Print Features:

* Added the possibility to selectively print some pages to TDBGPP.DLL.
  In the preview window, there are now 2 new menu items under "File":

     "Print &some pages", with the shortcut Ctrl+S, and
     "Print &current page", with the shortcut Ctrl+C.

  The current page is self-explanatory, print some pages opens a small
  modal dialog with the caption "Print some pages", and the prompt
  "Please enter the pages to print:" for the only plain edit field.
  The pages to be printed can be entered in a more or less free
  format, with the following rules:
 
     - any chars except digits and '-' are ignored;
     - any numbers separated by a '-' are treated as an (inclusive)
       range of pages;
     - a '-' at the beginning assumes '1-';
     - a '-' at the end assumes 'to the end';
     - all other numbers are treated as single page numbers.

  Sequence is not important unless in a range (i.e. a range 8-4 is
  empty, but "12, 1, 3-5" will print pages 1, 3, 4, 5, & 12.

  The following additional values have been added to the
  PrintInfo_MenuConstants enum:

     dbgpMenuPrintSomePages = 11  -- print some pages menu text
     dbgpMenuPrintCurrPage  = 12  -- print current page menu text
     dbgpDlgPagesCaption    = 13  -- print some pages dialog caption
     dbgpDlgPagesPrompt     = 14  -- print some pages dialog prompt
     dbgpDlgPagesOk         = 15  -- print some pages dialog 'ok'
                                     button text
     dbgpDlgPagesCancel     = 16  -- print some pages dialog 'cancel'
                                     button text.

  Both some and current page printing from the preview *ignore* the
  number of copies specified in the PrintInfo (reasoning is - those
  things are most useful when a page has been jammed - in which case
  honoring number of copies doesn't make sense).

  All above works even with the older versions of the grid (i.e.
  TDBGPP.DLL is backwards-compatible as usual), only numeric values
  must be used instead of the new enums.

* A new runtime-only property has been also added to the PrintInfo
  object: RangeOfPages, which is a string with the semantics described
  above. It is honored *only* by PrintData, and ignored by
  PrintPreview.



Version 6.0b ("Rosebush In Bloom"), Build 6.0.0213
--------------------------------------------------

Outlook-Style Grouping Features (OLE DB grid only):

* This new feature mimics the column grouping behavior of Microsoft 
  Outlook using grid splits to group columns. A tutorial has been 
  added to demonstrate this feature.  It can be found in the 
  \Tutorial\VB6\Oledb\Tutor25\ directory.  It uses the TDBGDemo.exe 
  database.

* A new grid collection, GroupColumns, is provided to allow the 
  programmer to obtain information about the current grouping order 
  and manipulate this order programmatically.  

* Two new properties: GroupByCaption (TDBGrid property) and Group 
  (Column property), as well as two new events: GroupColMove and 
  GroupHeadClick, were also added to support Outlook-Style Grouping.


New Printing Features:

* Similar to Microsoft Excel, the Print DLL can now accommodate 
  printing when the columns of grid data are too wide to fit onto one 
  page.  Additional pages are printed for the columns that do not fit.

* Several new shortcut properties have been added to allow access to 
  individual printer settings, rather than using the Settings property 
  to access all properties as a single unit.  Consult the 
  documentation for the PrintInfo object for details.

* New special symbols for printing page number data in the page 
  headers and footers have been added.


Miscellaneous Features:

* New AnimateWindow properties have been added to the grid that allow 
  you to control the style, direction, and duration of the animation 
  when the TDBDropDown control, built-in combo box, or CellTips window 
  are opened and closed.  These features are only available in Windows 
  98 and Windows NT 5.0 (Windows 2000).

* A new BatchUpdates property provides enhanced support for using the 
  OLE DB grid with an ADO Recordset in batch update mode (particularly 
  so when the grid is used in Internet Explorer).

* New AutoSize column method, which will resize a column to fit the 
  longest *visible* record in the column.

* The XArrayDB object has a new LoadRows method which will populate 
  the XArrayDB with data from any array in Visual Basic, such as that 
  returned by the ADO Recordset object's GetRows method.  Generic 
  Visual Basic arrays may also be used.



Version 6.0a ("Irises"), Build 6.0.0206
---------------------------------------

* A new property, DataView, has been added. The OLEDB version of True 
  DBGrid now supports the ability to display hierarchical  recordsets.  
  A tutorial has been added to demonstrate this feature.  It can be 
  found in the \Tutorial\VB6\Oledb\Tutor24\ directory.  It uses the 
  TDBGDemo.exe database.

* A new method, ExportToDelimitedFile, has been added. The OLEDB  
  version of True DBGrid now supports the ability to export rows (only 
  selected rows or all rows) to a delimited ASCII text file.

* A new column property, ConvertEmptyCell, has been added to both the 
  OLEDB and ICursor versions of the grid. This property allows you to 
  specify the what that is stored in the database when the column 
  value is cleared and the cell is empty.  You may choose to either 
  leave the empty cell as is (an empty string) or write a Null to the 
  database.
  
 
New Export Features:

* Checkboxes have been added to the export methods.

* A new method, ExportToDelimitedFile, has been added. You can now 
  export grid rows (all or selected) to a delimited  ASCII text file. 
  Rows are delimited with a newline character,  and each field value 
  can be defined with a prefix and suffix.


New Print Features:

* Print preview menu strings can now be replaced with user-specified  
  strings. Together with the PreviewPageOf property, the new features 
  are primarily provided to accommodate different end-user languages. 
  A new set of constants (MenuConstants) and two new methods 
  (SetMenuText and GetMenuText) have been added.

* Graphics support has been added to printing (not supported for 
  exporting). Now the print DLL prints all background and foreground 
  bitmaps that are present in the grid. Transparent foreground bitmaps 
  and checkboxes are also supported.

* When doing print preview, the formatted pages are now stored in a 
  temporary file on disk, so it is possible to print preview large 
  documents without exhausting memory.

* A new boolean property - PrintInfo.Draft has been added. Its default 
  value is False. If True, it will cause slightly faster printing at 
  the cost of lower output quality (e.g. draft-quality fonts and 
  lower-resolution background images)

* Font substitution has been enabled, via two new PrintInfo methods: 
  SubstituteFont, and GetSubstituteFont. Use these methods to specify 
  a substitution font with the same characteristics as the unavailable 
  font.  

* A new string property, PreviewPageOf, has been added to PrintInfo. 
  Use this property to control the string that is displayed in the 
  PrintPreview's page number field.

* A new shortcut, (Ctrl+P) has been added to PrintPreview, which will 
  print the document.



================================================
(3) Changes and Bug Fixes
================================================

The following list describes changes and bug fixes that have been made
to the latest release.


Version 6.0f ("Poet's Garden"), Build 6.0.0253
----------------------------------------------------

* Previously, it was not possible to remove a style twice. This has
  been fixed. (Bug #1520)

* There was a problem when referencing the SelBookmarks Count property
  from the SelChange event if the records were selected by holding
  down the SHIFT key, and using the up and down arrows. This has been 
  fixed. (Bug #2047)

* When the CycleOnClick property is set to True, the grid will not cycle 
  the value when the cell first receives focus. Now, the first clcik will
  set focus to the cell, and a second click will cycle the value in the 
  cell. (Bug #2101)

* Previously, the BeforeUpdate event did not fire when a new record was
  being added. This has been fixed. (Bug #5005)

* When the grid's DataView property was set to 1 - Hierarchical, it was
  possible to type in the grid, even though the grid is not updatable.
  This has been fixed, and now it is not possible to type within the
  grid when the DataView is set to Hierarchical. (Bug #5008)

* Plugged a memory leak that occured when adding and removing columns.
  (Bug #5067)

* Previously, the BeforeUpdate event would fire twice if the grid was
  updated through code. This has been fixed. (Bug #5071)

* Previously, a bound grid not connected to a recordset would return a
  value that was not Null for the LastRow parameter in the RowColChange
  event when the grid was first loaded. This has been fixed. (Bug #5079)

* There were some problems under Visual C++ when adding ValueItems through 
  the grid's property pages, in that clicking the Append button would close 
  the property pages. This has been fixed. (Bug #5171)

* The DropdownList property now functions properly in that when it is set to 
  True, is not possible to modify the cell's contents in any way. (Bug #5293)

* Previously, if a user clicked in a grid where the AllowFocus property was
  set to False for all the columns, the grid would scroll to the right. This
  has been fixed. (Bug #5288)
  



Version 6.0e ("Starry Night"), Build 6.0.0240
----------------------------------------------------

* Previously, opening a built in combo box and then calling the grid's 
  Update method (without selecting a new value or closing the combo
  first) would cause the Update method to fail.  This has been fixed.
  (Bug #1941)

* The BeforeRowColChange event previously did not fire when moving the 
  current cell to one in the same column and row, but in a different   
  split.  The event now fires in this case to allow users a chance to 
  cancel the movement. (Bug #1948)
  
* Fixed a bug relating to intrinsic check boxes and focus. 
  Previously, if the current cell contains a check box and has focus, 
  clicking on a cell in a different row that also contains a check box 
  will toggle its state, even if the AllowFocus property is set to 
  False for the column.  (Bug #1959)

* The calculations done to determine the value of the FullyDisplayed 
  argument of the FetchCellTips event always assumed that the WrapText
  property of the column was True. The actual value of the WrapText 
  property for the column is now properly taken into consideration.
  (Bug #1972)

* The AutoSize method now correctly factors in text in the current
  cell in its calculations when a Floating Editor MarqueeStyle is
  used.  (Bug #1995)

* Previously, if the current column of the grid contained a True 
  DBDate control as an external editor, interactively deleting the 
  last row in the grid did remove the record from then underlying data 
  source (in this case, a recordset), but did not remove the record 
  from the grid display. (Bug #2011) 

* Corrected several problems that caused the Form_Activate event not 
  to fire properly for a form containing the grid.  (Bug #2012, 2054)

* Fixed several problems associated with using a TDBInput control as 
  the external editor for a grid column in Batch Update mode, where 
  the pencil icon in the record selector column was displayed in the 
  wrong row, and incorrect values would be shown in the TDBInput 
  control itself.  (Bug #2023)

* Fixed a bug in Batch Update mode that caused all pending changes to 
  be lost any time setting a field value failed.  Now, only the change 
  to the problem field is undone, while all other pending changed
  remain.  (Bug #2032)

* Corrected a problem where a fatal exception was generated when a 
  grid using DataMode 4 - Storage is placed on an MDI child form and a 
  single MDI child window is opened, closed, and then reopened while
  running the application.  (Bug #2053)

* Attempting to update an unbound column containing a TDBDropDown 
  control in a grid bound to an ADO Data Control caused an incorrect 
  value to be displayed in the column.  (Bug #2055)

* Issuing an update in the OnAddNew event no longer causes row 
  currency problems.  (Bug #2056)

* In some cases, interactively removing a split (by resizing it to
  nothing) from the grid while an edit was in progress could 
  occasionally cause a GPF to occur.  (Bug #2059)

* Previously, when placing the grid into Edit mode using code (by
  setting the EditActive property to True), the DataChanged property
  would incorrectly be set to True in some cases.  Now, the 
  DataChanged property is set to True in this situation only if the 
  contents of a cell in the current row have been modified.  
  (Bug #2060, #2063)

* Fixed a problem related to deleting text using the context sensitive 
  menu in a cell containing an EditMask where the value of the 
  EditActive property was not correct. (Bug #2075)

* A GPF that occurred when moving the mouse over the grid has been
  fixed.  (Bug #2084)

* Fixed a problem where an empty grid was not painting properly when
  the Merge (Column) property was set.  (Bug #2091)

* Corrected a problem where the BeforeUpdate, AfterUpdate, and
  AfterInsert grid events were improperly firing when an AddNew 
  operation was initiated outside of the grid.  (Bug #2096)

* Previously, the ConvertEmptyCell property did not work correctly when
  the grid was bound to an ADO Data Control that is connected to a SQL
  Server database.  This has been corrected.  (Bug #2102)

* Issuing a Grid.Update on an unedited row no longer causes a Data
  Access Error.  (Bug #2108)

* Previously, setting the Locked attribute of a row's style using the
  EvenRowStyle/OddRowStyle properties or FetchCellStyle/FetchRowStyle
  events did not always lock the cells in the row properly.  This has 
  been fixed.  (Bug #2110)

* Fixed some problems where certain properties (such as the
  HeaderDivider property) were not being persisted properly when set
  from the property pages.  (Bug #2111)

* Previously, when the grid's MarqueeStyle property was set to
  3 - Highlight Row and focus as sent to another control inside of a
  grid event, the grid automatically gained focus back as soon as the
  mouse cursor were moved.  Fixed.  (Bug #2115)

* The grid now displays the correct icons in the record selector column 
  when editing and updating disconnected ADO recordsets.




Version 6.0d ("Four Cut Sunflowers"), Build 6.0.0235
----------------------------------------------------

* When setting the MultiSelect property to 0 - None, the grid did not
  permit you to select any rows --  the correct behavior is for the 
  grid to permit single row selection (only) in this case.  Fixed.
  (Bug #1110, #1712)

* When the grid was in an AddNew operation and the grid's Update 
  method was invoked while the AddNew row was scrolled off the 
  display, a Data Access Error was caused.  Fixed.  (Bug #1478)

* For a storage mode grid, if the first grid column contained an edit 
  mask, attempting to scroll the grid using the vertical scroll bar
  only caused the grid to flicker and not actually scroll.
  (Bug #1483)

* When using the floating editor MarqueeStyle, if you make the second
  split current in the Form_Activate event, it would sometimes
  require two mouse clicks to give focus to a particular column in the
  split.  (Bug #1499)

* The DataChanged property of a grid column was previously set to True
  when opening an associated TDBDropDown control, even when nothing
  was selected in the TDBDropDown.  Now the DataChanged property is 
  only set to True if an item is actually selected in the TDBDropDown.
  (Bug #1514)

* When the grid contains columns with similar DataField names, the 
  wrong field name was sometimes shown in the combo box on the
  right-hand side of the property page.  (Bug #1533, #1539)

* If a bound grid containing an automatic layout (one derived from the 
  ADO Data Control at runtime) had the DataView property set to 
  2 - Group, refreshing the ADO Data Control would not clear the 
  grouping information as it should.  This has been fixed.  If you 
  wish for the grouping information to be preserved across a data 
  control Refresh, you must use the grid's HoldFields method.
  (Bug #1534, #1839)

* Adding a new row to an OLE DB grid using DataMode 2 (Unbound
  Extended) and then canceling the AddNew using the Esc key 
  previously produced a GPF.  Fixed.  (Bug #1547)

* Previously, clicking on the RecordSelector of another grid row would
  permit the user to change grid rows even if the BeforeRowColChange
  event was cancelled.  Such movement is now (correctly) disallowed.
  (Bug #1555)

* In the OLE DB grid, when using DataMode 1 - Unbound for a grid that
  contains more columns than will fit on the screen, scrolling the 
  grid horizontally caused the data to appear in the wrong columns.
  Fixed.  (Bug #1561, #1565, #1668)

* The CycleOnClick property of the ValueItems collection now functions
  correctly when a column displays text-to-image ValueItems 
  translations.  (Bug #1564)

* When a TDBMask control was used as an ExternalEditor for a grid
  column, the literal characters in the mask were not being written
  back to the database.  This has been corrected.  (Bug #1581)

* Setting the MousePointer property now takes effect immediately,
  which did not happen previously in some cases.  (Bug #1600)

* It is now possible to enter DBCS Japanese characters into a 
  True DBInput 6.0 control (such as TDBText) that is used as the 
  external editor for a grid column.  (Bug #1603)

* In some cases, CellTips were not displaying correctly after a grid
  received focus from another control.  Fixed.  (Bug #1604)

* When using the context menu to paste data into a grid column whose 
  NumberFormat property is set to "Edit Mask", the grid did not set 
  the column's or grid's DataChanged property to True, and did not
  change the icon in the RecordSelector column to a pencil, causing 
  the newly pasted value to be lost when changing rows.  This has been 
  fixed.  (Bug #1628, #1741)

* The grid no longer causes a General Protection Fault (GPF) when
  setting the MarqueeStyle property in the BeforeColUpdate event.
  (Bug #1630)

* The events related to changing/updating column data  (AfterColEdit, 
  AfterColUpdate, BeforeColEdit, BeforeColUpdate, Change, ColEdit) now 
  correctly fire for columns that use built-in checkboxes 
  (ValueItems.Presentation = dbgCheckBox).  (Bug #1633, #1740)

* In some cases, after expanding multiple rows in a hierarchical grid, 
  the grid would not display data correctly after the CollapseBand
  method was used to collapse the expanded rows.  Fixed.  (Bug #1658)

* In some cases, changing style properties on the General property 
  page of the TDBDropDown control would create an infinite series of
  "Invalid setting for property" error message.  This has been
  corrected.  (Bug #1666)

* When dragging non-text data into a grid, the grid now correctly 
  fires the OLE Drag and Drop events.  Note that the OLEDragMode and 
  OLEDropMode properties must be set to 1 - Manual for this to work
  correctly, since the grid can only handle text data in Automatic 
  mode.  (Bug #1691, #1692)

* In rare cases, the Remove method of the Columns collection would 
  unexpectedly fail.  This has been corrected.  (Bug #1700)

* All creatable objects in the grid OCX (such as the grid's Style and 
  ValueItem objects) have now been marked safe for scripting.
  (Bug #1721)

* Setting the CurrentCellModified property to False now correctly
  restores the previous cell value.  (Bug #1739)

* Setting the DataWidth property of a column in the RowColChange event
  when using a MarqueeStyle of 6 - Floating Editor previously did not
  take effect until the next RowColChange event was fired.  The grid
  now honors the request immediately.  (Bug #1745)

* A memory leak that occurred in the OLE DB grid when using DataMode
  4- Storage has been plugged.  (Bug #1754)

* It is now possible to use a value higher than 326 as the Width
  argument of the ExportToFile method without causing an Abnormal
  Program Termination error in Visual Basic.  (Bug #1755)

* Previously, a grid displaying a hierarchical recordset would not
  always refresh correctly when the Close and Open methods were
  executed.  Fixed.  (Bug #1793)

* If the grid was bound to an XArrayDB that initially contained no 
  rows, and the ReBind method of the grid was executed after adding a 
  new row to the array, the first row would incorrectly be cleared.  
  This has been corrected.  (Bug #1799)

* Fixed a problem where the column HeaderDivider property setting was 
  not correctly being persisted for any split other than the first.
  (Bug #1800)

* Previously, when setting the EditMask for a column to "###", the 
  grid would (illegally) allow you to enter "7 7".  Fixed.
  (Bug #1804)

* The grid previously allowed the current row to be changed within the
  BeforeColUpdate event, which would cause a General Protection Fault
  (GPF).  Now the grid correctly disallows row movement in the
  BeforeColUpdate and AfterColUpdate events.  (Bug #1810)

* When working with an OLE DB grid that was connected to a data source 
  using server side cursors, correct update notifications were not
  being sent to the grid, which would remain in edit mode.  This has 
  been worked around.  (Bug #1836)

* Worked around a bug in ADO that causes the grid's AfterInsert and
  AfterUpdate events to behave incorrectly for filtered recordsets.
  (Bug #1844)

* In one case, compiling a project containing a True DBGrid Pro 6.0
  control which was migrated from the 5.0 version would cause a 
  General Protection Fault (GPF).  This seemed to occur when the 5.0
  grid contained a Style that had been created at design time and was
  not assigned a Parent style.  Fixed.  (Bug #1846)

* Plugged a memory leak that occurred when setting the grid's Array
  property again after it had already been set once.  The grid now
  frees the reference to the original object when the Array property
  is set a second time.  (Bug #1879)

* Attempting to delete a row in the grid after a prior AddNew 
  operation was canceled caused several display problems.  Fixed.
  (Bug #1889)

* Previously, if a Filter were applied to the recordset to which the
  control is bound, the grid would not longer react properly to an 
  AddNew, and all of the grid's rows disappear except for the AddNew
  row. This occurs if the grid is bound to an ADO data control or to a
  disconnected recordset using the SQLOLEDB or MSDataShape provider.
  Fixed. (Bug #1906)

* According to the documentation, the LeftColChange event is triggered 
  under several circumstances, including when the user moves the
  current left column or moves another column into its place.
  Actually, the event did not fire when the user manually moves the 
  leftmost column to another position.  This has been corrected.
  (Bug #1926)

* Columns whose OwnerDraw property is set to True are now rendered
  correctly when the PrintData or PrintPreview methods are executed.

* When changing the zoom factor of the grid in the PrintPreview
  window to a fairly high value (approximately 150% or higher), the
  bottoms of DBCS characters in the grid were not being clearly 
  displayed.  This has been fixed.

* When displaying pictures in cells, the location of the picture in
  the cell was sometimes incorrect when viewing the grid using the
  PrintPreview method.  Fixed.

* Previously, the CellContaining method did not indicate the correct
  row index if split captions were used.  This has been corrected.

* Rearranging columns by dragging their headers now gives proper
  results when the grid contains two or more splits and one of the 
  split's SizeMode property is set to 2 - Number of Columns.

* In some cases, setting the AllowFocus property to False for a column 
  would not prevent the user from entering or modifying data.  Fixed.

* Previously, when setting the Caption property of a column to a
  string containing DBCS characters using the property pages would
  cause the characters would become garbled when the Apply button was
  pressed.  The characters remained garbled until the property pages 
  were closed once and re-opened.  Fixed.

* In some circumstances, the divider between the Value and 
  DisplayValue columns of the small grid on the Values property page 
  would disappear.  It is now displayed correctly.

* The translated value of the default item of a column's ValueItems
  collection is no longer displayed in the AddNew row of the grid.

* The end-user can no longer press the PageDown key to leave the 
  current row if the BeforeUpdate event was cancelled.

* The grid exhibited display problems if both the MultipleLines and 
  Outlook Grouping behavior were enabled.  These two features were 
  always intended to be mutually exclusive, and this is now properly 
  enforced.

* Sometimes dragging a column header into the column grouping area,
  followed by using the horizontal scroll bar, would cause the scroll
  bar to be displayed incorrectly.  This has been fixed.

* Previously, when the right border of a split was right next to the 
  vertical scroll bar, the scroll box (thumb) would not move.  This is
  now fixed.

* The MarqueeStyle setting of 7 - dbgDottedRowBorder is now displayed
  correctly in multiple line mode.

* In some cases, scrolling the grid by dragging the scroll box (thumb)
  after setting the Bookmark property would cause the last grid row to
  be displayed incorrectly.  Fixed.

* Deleting the last row in the OLE DB grid using the grid's Delete
  method now correctly repositions the grid to the previous row (which
  becomes the "new" last row).

* If the RowHeight property of the grid was set small enough to cause 
  the cell text to be clipped, the multiline pop-up text editor
  (EditDropDown property) would sometimes appear in the wrong 
  position.  Fixed.

* Several persistence problems related to properties on the Values 
  property page have been corrected.

* The ReBind method of the OLE DB grid previously caused the first row
  of the data source to become the current row.  Now the current row 
  Bookmark is maintained across a ReBind for the OLE DB grid, just as
  it does for the ICursor version.  

* When rearranging columns interactively in multiple line mode near
  the right edge of the grid, the red markers that indicate where the
  column will be moved to were not shown in the correct location.
  Fixed.


Version 6.0c ("Green Wheat Fields"), Build 6.0.0220
---------------------------------------------------

* A rounding error sometimes caused column widths to shrink by a small 
  amount every time the project is run.  This has been corrected. (Bug 
  #1181, #1420, #1425)

* In some cases, with the OLE DB version of the grid, some data cells 
  would appear empty when printing or exporting grid data. This has 
  been corrected. (Bug #1297, 1448)

* Several problems were fixed relating to the Values tab of the 
  property pages. (Bug #1319)

* The NumberFormat property now works correctly for the format string 
  "mm/dd/yyyy" when the underlying date value is empty. (Bug #1362)

* The Retrieve Fields context menu command now works correctly when 
  the grid is bound to a Data Environment. (Bug #1375)

* If the XArrayDB was dimensioned to 0,-1,0,4 only three columns were 
  visible in the grid (instead of five).  This has been corrected. 
  (Bug #1377)

* Using the Clear method of the DataObject object in the OleStartDrag 
  event now works correctly. (Bug #1378)

* The AfterUpdate and BeforeUpdate events now fire correctly when the 
  grid is used in Internet Explorer. (Bug #1382)

* The GetBookmark method now correctly returns a NULL value when the 
  targeted row is on/before BOF or on/after EOF. (Bug #1390)

* Resizing a merged column no longer causes a GPF. (Bug #1395)

* Previously, if editing was disallowed for certain rows in the grid 
  by setting the Locked property of the Style object passed into the 
  FetchCellStyle or FetchRowStyle events, the grid would still allow 
  you to toggle/cycle the cell value by clicking on the cell.  The 
  grid now (correctly) disallows cell edits using this technique. (Bug 
  #1410)

* Sometimes re-dimensioning the XArrayDB object after invoking the 
  LoadRows method would cause a GPF.  This is now fixed. (Bug #1450)

* The AddRegexCellStyle method now works properly for cells in merged 
  columns. (Bug #1454)

* Several problems relating to multi-line mode have been corrected. 
  (Bug #1465)

* The grid's display no longer becomes unstable in Outlook-Style 
  Grouping mode if you drag a column header to the grouping area and 
  then attempt to drag a cell somewhere in the grid. (Bug #1485)

* Fixed a memory leak which occurred when images are loaded into the 
  grid using the FetchCellStyle or FetchRowStyle events. (Bug #1490)

* Executing the Refetch method on a column in a bound grid no longer 
  gives an Automation Error.

* Fixed several problems associated with Picture-related properties in 
  the grid's property pages.

* Some Header*, Footer*, Button*, EditMask* properties were not being 
  properly saved when changed by the user.  This is now fixed.

* Inconsistencies in behavior between the ICursor and OLE DB grids 
  when setting the Bookmark property have been corrected.

* In some cases, deleting the last row of the grid and issuing the 
  ReBind method would cause the grid to blank out when the grid was 
  bound to the Visual Basic built-in (DAO) Data Control.  This has 
  been fixed.

* For the ICursor grid, if you change the AbsolutePosition property of 
  the Data Control's Recordset, data will not show properly in the 
  grid.  Fixed.

* Fixed a GPF that would occur sometimes when dragging the mouse over 
  a selected column whose ExtendRightColumn property is True.

* The RefetchCell method now behaves correctly if the optional 
  argument is omitted.

* The ButtonClick event now fires when you press the Spacebar while 
  the grid's current cell is rendered as a command button (ButtonText 
  property of the column is True).

* The OwnerDrawCell event parameters are now correct for cells in 
  merged columns.

* Fixed several problems where the grid would exhibit strange or 
  incorrect behavior when using or processing DBCS characters.

* Some problems with the XArrayDB Find and QuickSort methods have been 
  fixed, several of which involve international characters.

* A problem with the TDBDropDown control not being sized correctly 
  when the IntegralHeight property is set to True has been fixed.

* Grid column indices were previously 1-based in the OwnerDrawCell 
  event, which is incorrect.  The event now correctly reports 0-based 
  column indices.  This will require changes to code in the 
  OwnerDrawCell event.  Previously, it was necessary to use (Col-1)
  when referencing grid columns using the supplied parameters.  
  Instances of (Col-1) should now be changed to simply (Col).

* Typing an invalid value into the grid's property pages in Visual C++ 
  no longer causes an infinite series of message boxes.

* In Visual C++, if column widths were set using the property pages or 
  through visual editing mode, the column widths would appear 
  different if the project were subsequently loaded into a computer 
  where the graphics resolution or small/large font settings were not 
  the same as the original.  In order for the fix to take effect after 
  installing the OCX on your computer, you must cause the project's 
  resources to be re-saved.  Toggling the value of a  property on the 
  property pages should do the trick -- then save and recompile your 
  project.


Version 6.0b ("Rosebush In Bloom"), Build 6.0.0213
--------------------------------------------------

* Check boxes are now aligned correctly when the column alignment is 
  set to dbgCenter.  (Bug #1089)

* AddNew now works correctly for ADODB recordsets with the LockType 
  property set to adLockBatchOptimistic.  Make sure to set the new 
  BatchUpdates property to True in this case.  (Bug #1090)

* When the MarqueeStyle property was set to dbgHighlightRowRaiseCell 
  the appearance was the same as dbgHighlightRow (the cell was not 
  raised).  This has been fixed.  (Bug #1120)

* Fixed problem where the grid did not print when attached to a Data 
  Environment.  (Bug #1124)

* Corrected problem with printing when the VariableRowHeight property 
  was set.  (Bug #1125)

* Corrected a problem where using the PrintPreview method with the 
  dbgSelectedRows argument would produce a run time error in the Print 
  DLL.  (Bug #1128)

* A GPF that occurred when maximizing the PrintPreview window (Win95, 
  Win98 only) was fixed.  (Bug #1136)

* The FetchRowStyle event now fires correctly when the current row is 
  changed.  (Bug #1148)

* Previously, a grid using the Hierarchical data view was editable 
  under some conditions, when it shouldn't have been.  This has been 
  fixed.  (Bug #1151)

* Corrected a problem where the grid would not correctly print when 
  using the Hierarchical data view.  (Bug #1153)

* Problems associated with deleting the row of an XArray containing 
  only a single row have been corrected.  (Bug #1158)

* Executing the Close method for the OLE DB grid no longer results in 
  a GPF  (Bug #1159)

* A small memory leak in the OLE DB grid was fixed.  (Bug #1160)

* The NumberFormat property now works correctly for following format 
  string: "m/d/yyyy"  (Bug #1161)

* Fixed a problem involving a project containing multiple grids when 
  layouts are saved for all the grids.  Previously, only the last 
  layout saved was handled correctly.  (Bug #1169)

* Corrected a problem where the built-in combo was left floating when 
  user presses Alt+Tab to switch between applications.  (Bug #1170)

* Fixed a problem where in some cases the TDBDropDown would sometimes 
  produce a data type mismatch error.  (Bug #1174)

* Previously, if you set the heading style font in the grid's 
  property, pages the height of the column headers did not adjust in 
  the grid.  this has been corrected.  (Bug #1176)

* Corrected a problem where printing the grid from an application 
  (EXE) that uses the grid in DataMode 2 - Unbound Extended, produced 
  a DLL error.  (Bug #1199)

* Corrected a problem with the OLE DB grid where grid bookmarks and 
  XArrayDB row numbers were out of sync after deleting rows.  (Bug 
  #1214)

* Fixed a problem where the PrintPreview window would sometimes show 
  the preview page in lower right corner when you changed the page 
  setup settings (for example to Landscape orientation) before 
  executing the PrintPreview method.  (Bug #1217)

* The ZOrder was wrong after PrintPreview window was closed in Visual 
  C++.  This has been corrected.  (Bug #1218)

* Empty layouts can now be removed from the layout files.  (Bug #1220)

* Corrected a problem where the BeforeInsert event was fired twice 
  when the grid is bound to the Microsoft Remote Data Control.  (Bug 
  #1221)

* Fixed a problem where the ComboSelect event was not firing for the 
  Tab key if the TabAction property was set to dbgGridNavigation.  
  (Bug #1234)

* Data was not being correctly formatted in BeforeColUpdate event in 
  all cases.  This has been corrected.  (Bug #1278)

* The End and Home keys now correctly trigger the BeforeRowColChange 
  event.  (Bug #1292)

* The HTML Export facility now correctly accounts for moved columns.  
  (Bug #1297)

* Fixed a problem where a column would sometimes appear in black on 
  the PrintPreview page.  (Bug #1306)

* Printing now works correctly for merged columns.  (Bug #1310)

* Fixed a problem when the ButtonHeader property is True for a column 
  where the HeadClick Event did not fire when the mouse was moved 
  between MouseDown and MouseUp events, but was still positioned over 
  the header.  (Bug #1312)

* Corrected a problem where the BeforeColUpdate event fired twice when 
  tabbing off the column and the OldValue parameter was set to a 
  different value in code.  (Bug #1314)

* The ConvertEmptyCell now works correctly for a grid bound to a 
  DataEnvironment.  (Bug #1318)

* Previously, if you opened a TDBDropDown control attached to a column 
  in the grid and resized one of its columns, subsequently moving the 
  form on the screen would cause the dropdown would stay open and at 
  the same place.  This has been corrected.   (Bug #1335)

* Previously, if the grid was printed or exported and 
  RepeatColumnFooters was False, the column footer would be printed at 
  the bottom of the first page.  Now in this case, the column footer 
  is (correctly) printed only at the bottom of the last page.   If 
  RepeatColumnFooters is True, the column footer is still printed at 
  the bottom of every page, as it was previously.



Version 6.0a ("Irises"), Build 6.0.0206
---------------------------------------

* The online help file now correctly documents the behavior of the 
  Refresh and ReBind methods in Storage mode (DataMode 4). NOTE: The 
  information in the manual IS correct as written.

* PrintInfo.BlackAndWhite property has been removed.

* Print, print preview, and export should now handle all grid styles 
  correctly, including styles changed via Fetch...Style methods.  
  NOTE: During printing (or print previewing) the user fetch style 
  events are fired from the printing thread. As a result, if a 
  breakpoint is set by the VB developer in the VB event handler code, 
  VB sometimes will appear to hang when this breakpoint is arrived at 
  during printing. As a possible solution, debug methods that do not 
  require user input can be used to debug such code (e.g., 
  Debug.Print).

* Some specific errors are now generated by the print code instead of 
  the generic failure.

* If column update fails because of an illegal cell value (incorrect 
  date or number format, for example), the illegal value stays in the 
  cell and the grid remains in edit mode. This enables the user to 
  correct the error without having to retype the entire value. Earlier 
  versions automatically restored the previous value on column update 
  failure.  (Applies to both the OLE DB and ICursor versions)

* The grid will exit editing mode upon losing focus only if the focus 
  shifts from the grid to another control on the same form. If the 
  focus shifts from the grid to a different form or to a message box, 
  edit mode is maintained. (Applies to both the OLEDB and ICursor 
  versions)

* HighlightRow style no longer ignores the setting of Font.Bold.

* Column merging behavior is now correct when a text-to-picture 
  ValueItems translation is used in the column. 

* The grid will now print when bound to a Data Environment.

* Ctrl+Tab now works correctly between multiple forms.

* A column in Split 1 will no longer disappear when you are trying to 
  resize it.

* The grid will now print correctly when the WrapText property is set 
  to True.

* The grid will now display correctly when the Appearance is Flat and 
  RowDividerStyle is Inset.

* The scrollbar in the built-in combo box now works properly.

* If no item matches the text in the current grid editor cell, no item 
  will be selected in the dropdown.

* Pressing the Tab key when dropdown is open will move the cursor to 
  the next column.

* Selecting from the TDBDropdown or built-in combo box now marks the 
  row as dirty.

* VariableRowHeight now sizes printed rows correctly, and no longer 
  shrinks the rows.

* When RowDividerStyle is set to None, the row dividers are now 
  (correctly) not printed.

* Checkboxes now align correctly.

* Grid cell data can now be properly analyzed for regular expression 
  conditions.

* Date problems with the FormatText event and regional settings have 
  been cleared up.

* The XArrayDB Find method now returns the correct value in Windows 
  98.

* Editor sizing inconsistencies have been corrected.

* The MarqueeStyle constant dbgHighlightRowRaiseCell now works 
  properly.

* If the VariableRowHeight property is set to True and a comment field 
  is visible on the page, excess printing no longer occurs.

* A run time error no longer occurs when closing PrintPreview with 
  nothing selected.




================================================
(4)  Explanation of ICursor and OLE DB
================================================

There are two types of data binding formats currently available for
data-bound controls and data controls, ICursor and OLE DB.  These two
data binding formats are not compatible with each other.  Thus, you 
cannot bind an OLE DB data-bound control to an ICursor data control,
or vice versa.  You must bind ICursor data-bound controls to ICursor
data controls, and OLE DB data-bound controls to OLE DB data controls.  
Most data-bound controls and data controls support only ICursor or OLE 
DB; usually not both.

ICursor is supported by the Visual Basic 5.0 and 6.0 intrinsic data 
controls, as well as the Microsoft Remote Data Control.  All 
data-bound controls that shipped with Visual Basic 5.0 support 
ICursor, as do many that ship with Visual Basic 6.0.  

OLE DB is a new data binding specification supported by the ADO Data 
Control (ADODC) that ships with Visual Basic 6.0.  Visual Basic 6.0 
also ships with a number of OLE DB data-bound controls, such as the 
Microsoft DataGrid and DataList controls.  OLE DB controls are 
generally marked with (OLEDB) in the Visual Basic 6.0 component 
gallery for your convenience.  (If a control is not labeled with 
(OLEDB), you can usually assume that it supports ICursor, and not OLE 
DB.)

True DBGrid Pro 6.0 supports both ICursor and OLE DB data binding by 
supplying two OCX grid controls:

The ICursor grid (TDBG6.OCX) supports binding to ICursor data 
controls, such as the VB5/VB6 intrinsic data controls and the 
Microsoft Remote Data Control (RDC).

The OLE DB grid (TODG6.OCX) supports binding to OLE DB compliant data 
controls, such as the ADO Data Control (ADODC) that ships with VB6.

The ICursor and OLE DB versions of True DBGrid Pro 6.0 support the 
same rich set of data presentation and user interface features, 
differing only in the types of data controls and data sources 
supported.  


NOTE: Both the ICursor and OLE DB grids support the same unbound data 
modes, although the unbound modes of the ICursor grid (TDBG6.OCX) are 
more efficient than those of the OLE DB grid (TODG6.OCX), which have 
not yet been fully optimized.



================================================
(5)  Samples and Tutorials
================================================
  
About the Tutorials
-------------------

True DBGrid Pro 6.0 ships with several sets of tutorial and sample 
projects.  

All Visual Basic 5.0 tutorials and samples use the ICursor grid 
(TDBG6.OCX).

There are two sets of True DBGrid 6.0 tutorials and samples for Visual 
Basic 6.0, one for the ICursor grid (TDBG6.OCX), and one for the OLE 
DB grid (TODG6.OCX). 


Running the HTML Tutorials
--------------------------

The HTML tutorials and samples were designed for Windows NT 4.0 
systems with Windows NT 4.0 Service Pack 3 (or later) and Internet 
Explorer 4.0 installed.  For most of the tutorials and samples, you 
will need the Remote Data Services data control (RDS) installed on 
your system.  RDS is a component of Internet Information Server (IIS) 
4.0, which is installed by the Microsoft Windows NT 4.0 Option Pack.  
As of the time of this writing, you may download the Option Pack from 
the following URL:
        
http://www.microsoft.com/NTServer/all/downloads.asp

To obtain IIS 4.0 for other operating systems, please contact 
Microsoft or visit their web site at:

http://www.microsoft.com/


Extra Sample Projects
---------------------

Also included with this product is a collection of extra unbound and 
storage mode projects compiled by the APEX support staff which have 
been found to be useful by our customers and beta testers.  These 
extra samples have been placed into the \Samples\Extra folder where 
you installed True DBGrid Pro 6.0.  These projects are not documented 
and not officially supported by APEX, although we will try to answer 
questions about them.

Many of these extra sample projects are very valuable and useful.  
Some show how to use the grid with ADO, DAO, and RDO in unbound mode, 
some show how to dump Recordset or Resultset data into an XArray or 
XArrayDB object, and others show miscellaneous features and tips.  
Most of the sample projects in the \Samples\Extra folder contain a 
Readme.txt file that gives a small description of the sample.

Enjoy!



================================================
(6)  Migration
================================================

A migration utility is provided for you to migrate projects created 
with DBGrid, True DBGrid 4.0, and True DBGrid Pro 5.0 ICursor grid 
controls to True DBGrid Pro 6.0 (ICursor) or True DBGrid Pro 6.0 (OLE 
DB).

The migration utility can also be used to migrate a True DBGrid Pro 
6.0 (ICursor) project to True DBGrid Pro 6.0 (OLE DB), and vice versa.  
Note however that when migrating from an ICursor control to an OLE DB 
control (or vice versa) will *only* replace the grid for you and 
modify grid code.  The migration utility does not replace the data 
control or migrate any data access code for you, which you must do 
yourself. 

Example:  If you migrate a True DBGrid Pro 5.0 project which uses the 
VB6 Data control to True DBGrid Pro 6.0 (OLE DB), the migration 
utility will change event declarations and TrueDBGrid50 to 
TrueOleDBGrid60 as appropriate, but the project will not work (the 
grid is now OLE DB, which is incompatible with the VB6 intrinsic 
(ICursor) data control.  You must then replace the VB6 Data control 
with an OLE DB data control (such as the ADO data control which ships 
with VB6) and replace all data control code in your project.



================================================
(7)  Distribution Requirements
================================================


The following listing contains all redistributable True DBGrid Pro 6.0 
files provided by APEX:

TDBG6.OCX     (APEX True DBGrid Pro 6.0 ICursor grid)
TODG6.OCX     (APEX True DBGrid Pro 6.0 OLE DB grid)
TODGUB6.DLL   (Unbound mode support DLL for use with TODG6.OCX)
TDBGPP.DLL    (Printing and print preview support DLL)
XARRAY32.OCX  (APEX XArray Object)
XARRAYDB.OCX  (APEX XArrayDB Object)


The guidelines below will list the necessary files which must be 
distributed with programs that use True DBGrid Pro 6.0.  (NOTE: The 
guidelines below do not list Visual Basic, OLE, or Database-related 
run time support files which may also be required for distributing 
your project.)


If you are using the ICursor version of True DBGrid Pro 6.0:
------------------------------------------------------------

* You must ALWAYS distribute TDBG6.OCX.

* If you are using XArray anywhere in your project (with or without 
  the grid), you must distribute XARRAY32.OCX.

* If you are using XArrayDB anywhere in your project (with or without 
  the grid), you must distribute XARRAYDB.OCX.

* If you are using the grid's printing or exporting features, you must 
  distribute TDBGPP.DLL.


If you are using the OLE DB version of True DBGrid Pro 6.0:
------------------------------------------------------------

* You must ALWAYS distribute TODG6.OCX.

* If you are using any grids in your project where the DataMode is set 
  to 1 (Unbound), 2 (Unbound Extended), 3 (Application), or 4 (Storage 
  Mode), you must distribute TODGUB6.DLL.

* If you are using XArray anywhere in your project (with or without 
  the grid), you must distribute XARRAY32.OCX.

* If you are using XArrayDB anywhere in your project (with or without 
  the grid), you must distribute XARRAYDB.OCX.

* If you are using the grid's printing or exporting features, you must 
  distribute TDBGPP.DLL.



----------------------------------------------------------------
Thank you, 
ComponentOne LLC

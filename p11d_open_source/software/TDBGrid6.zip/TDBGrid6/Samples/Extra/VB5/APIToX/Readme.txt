This sample shows how you can populate XArrayDB from an ODBC database.  The advantage is that there is no overhead of DAO, ADO or RDO.
Use this if you want a quick, read only grid displaying data through ODBC.  For fully editable grid see the ODBC unbound2 sample.

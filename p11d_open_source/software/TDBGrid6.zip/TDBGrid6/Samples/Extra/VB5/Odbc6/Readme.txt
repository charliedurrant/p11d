This sample shows how you can use ODBC API to populate the grid in Unbound extended mode.

Note:  The vertical scroll bar will not be accurate because there is no way for the ODBC driver to report an Absolute position for a row.
